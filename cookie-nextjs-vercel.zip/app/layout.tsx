import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "COOKIE. — Good food, good people",
  description: "Contemporary food, beautiful ingredients and nights worth staying out for.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
