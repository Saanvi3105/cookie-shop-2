export default function Home() {
  return (
    <main className="site-frame">
      <iframe
        src="/cookie.html"
        title="COOKIE restaurant website"
        className="site-iframe"
      />
    </main>
  );
}
