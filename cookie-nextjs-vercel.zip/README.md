# COOKIE Restaurant Website (Next.js)

## Run locally
1. Install Node.js LTS from https://nodejs.org/
2. Extract this ZIP and open the folder in VS Code.
3. In the VS Code terminal, run:
   ```bash
   npm install
   npm run dev
   ```
4. Open http://localhost:3000

## Deploy to Vercel
1. Push this folder to a GitHub repository.
2. Go to https://vercel.com/new and import the repository.
3. Keep the default Next.js settings and click Deploy.

The booking form is a front-end demo and does not contact a real restaurant.
